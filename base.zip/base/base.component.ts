import { Component, OnInit } from '@angular/core';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';

@Component({
  selector: 'app-base',
  templateUrl: './base.component.html',
  styleUrls: ['./base.component.css']
})
export class BaseComponent implements OnInit {

  constructor()  {}

    
  //  submit(){
  //     Showalert("askj")
  // }
  

  

  ngOnInit(): void {
    
    
  }

}
function Showalert(arg0: string) {
  throw new Error('Function not implemented.');
}

